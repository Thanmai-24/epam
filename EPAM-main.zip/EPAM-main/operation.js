var a = 10;
var b = 25;

document.write("Addition is: " + (a + b) + "<br>");
document.write("Subtraction is: " + (a - b) + "<br>");
document.write("Division is: " + (a / b) + "<br>");
document.write("Modulus is: " + (a % b) + "<br>");
document.write("Multiplication is: " + (a * b) + "<br>");
document.write("Increment Output (Post-increment) is: " + (a++) + "<br>");
document.write("Increment Output (Post-increment) is: " + (a--) + "<br>");