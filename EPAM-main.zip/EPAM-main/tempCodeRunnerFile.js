var a = "99";

var b = 99;

document.write(typeof(a));
document.write("<br><br>");
document.write(typeof(b));
var c = parseInt(a);
document.write("<br><br>");
document.write(typeof(c));
document.write("<br><br>");
var d = String(b);
document.write(typeof(d));