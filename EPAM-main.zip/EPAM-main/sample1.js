let apple = "fruit";

console.log(apple);
let apple1 = "fruit";

console.log(apple1);
let apple2 = "fruit";

console.log(apple2);
let apple3 = "fruit";

console.log(apple3);
let apple4 = "fruit";

console.log(apple4);